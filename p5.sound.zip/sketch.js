
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var engine,world;
var paperObject;


function setup() {
	createCanvas(1200,500);

	engine = Engine.create();
	world = engine.world;

	//Create the Bodies Here.
	dustbin = new Dustbin(810,160,70,70);
    paperObject = new paperObject(810,160,2); 
  

	Engine.run(engine);

function draw() {
  rectMode(CENTER);
  background(0);
    Engine.update(engine);
    console.log(paperObject.body.position.x);
    console.log(paperObject.body.position.y);
    console.log(paperObject.body.angle);
  drawSprites();
 ellipse();
}

function keyPressed() {

if(keyCode === UP_ARROW) {

Matter.Body.applyForce(paperObject.body,paperObject.Body.position,{x:85,y:-85});

}

}

}



